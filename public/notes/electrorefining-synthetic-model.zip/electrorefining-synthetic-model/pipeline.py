#!/usr/bin/env python3
"""SYNTHETIC ONLY. Reproducible grouped chronological modeling demonstration."""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
os.environ.setdefault("MKL_NUM_THREADS", "2")
import argparse
import copy
import csv
import hashlib
import json
import math
import pickle
import platform
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import sklearn
import catboost
from catboost import CatBoostRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits

ROOT = Path(__file__).resolve().parent
M_CU = 0.063546  # kg/mol
F = 96485.33212  # C/mol
TARGETS = ["efficiency_pct", "s_grade_pct", "cu_out_g_l", "as_out_g_l"]
SENSORS = ["current_a", "cell_voltage_v", "temperature_c", "flow_l_min", "on",
           "short_detected", "short_removed", "glue_dose_g_h", "thiourea_dose_g_h", "hcl_dose_ml_h"]
CHEM = ["cu_in_g_l", "cu_out_g_l", "as_in_g_l", "as_out_g_l", "ni_g_l", "bi_mg_l",
        "h2so4_g_l", "cl_mg_l", "glue_measured_mg_l", "thiourea_measured_mg_l"]
META = {"cycle_id", "section_id", "batch_id", "campaign_index", "start_hour", "end_hour",
        "active_area_m2", "planned_current_a", "anode_cu_pct", "anode_as_pct", "surface_index"}
OBS_ALLOWED = set(SENSORS + ["cycle_id", "observed_hour", "available_at_hour", "elapsed_hour", "dt_h"])
LAB_ALLOWED = set(CHEM + ["cycle_id", "observed_hour", "available_at_hour", "elapsed_hour"])
MODELS = [{"id": "mean_baseline", "name": "Train mean baseline"},
          {"id": "catboost_raw", "name": "Independent CatBoost: observed summaries"},
          {"id": "catboost_physics", "name": "Independent CatBoost: physics augmented"},
          {"id": "shared_mlp_physics", "name": "Shared multioutput MLP: physics augmented"}]


def dump(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)


def faraday(charge_c):
    return M_CU * charge_c / (2 * F)


def bounded_normal(rng, mean, std, lo, hi):
    # Only generating the assumed DGP uses bounds; model predictions are never clipped.
    return float(np.clip(rng.normal(mean, std), lo, hi))


def generate(cfg, seed):
    rng = np.random.default_rng(seed)
    cycles, observations, labs, labels, audit = [], {}, {}, [], []
    h = np.arange(2, 169, 2, dtype=float)
    for campaign in range(cfg["n_campaigns"]):
        batch_z = rng.normal()
        drift = campaign / 15
        for cell in range(cfg["cells_per_campaign"]):
            cid = f"C{campaign:02d}_S{cell:02d}"
            start = campaign * cfg["campaign_spacing_hours"]
            local_z = rng.normal()
            area = bounded_normal(rng, 120, 6, 105, 135)
            plan_i = bounded_normal(rng, 33000 + 1300 * batch_z, 2200, 25000, 41000)
            surface = bounded_normal(rng, 0.5 + 0.09 * local_z, 0.12, 0, 1)
            anode_as = bounded_normal(rng, .17 + .025 * batch_z, .04, .05, .35)
            meta = dict(cycle_id=cid, section_id=f"SECTION_{cell:02d}", batch_id=f"BATCH_{campaign:02d}",
                        campaign_index=campaign, start_hour=start, end_hour=start + 168,
                        active_area_m2=area, planned_current_a=plan_i,
                        anode_cu_pct=bounded_normal(rng, 98.8, .25, 98, 99.6),
                        anode_as_pct=anode_as, surface_index=surface)
            cycles.append(meta)
            temp_base = bounded_normal(rng, 60 + 3 * drift + .9 * batch_z + .4 * local_z, 1.8, 53, 70)
            flow_base = bounded_normal(rng, 32 + 2 * batch_z, 5, 18, 48)
            glue_d = bounded_normal(rng, 3.5 + .3 * local_z + .2 * batch_z, .7, 1, 6)
            thio_d = bounded_normal(rng, 1.1 + .1 * local_z, .22, .35, 1.9)
            hcl_d = bounded_normal(rng, 80 + 7 * batch_z, 12, 35, 125)
            cu_base = bounded_normal(rng, 45 + 1.5 * batch_z + 1.8 * drift, 2.5, 35, 57)
            as_base = bounded_normal(rng, 7 + .6 * batch_z + 3 * anode_as, .7, 4, 11)
            ni = bounded_normal(rng, 9 + .8 * batch_z, 1.5, 4, 15)
            bi = bounded_normal(rng, .9 + .15 * local_z, .2, .15, 1.8)
            acid = bounded_normal(rng, 180 + 3 * batch_z, 7, 155, 205)
            cl = bounded_normal(rng, 35 + .12 * hcl_d, 5, 20, 70)
            obs, lab, chemistry = [], [], []
            short_active = False
            for elapsed in h:
                on = float(rng.random() > (.014 + .008 * drift))
                # Unplanned current deviations cannot enter the planned scenario feature.
                current = on * plan_i * (1 + .025 * np.sin(elapsed / 23) + .025 * drift + rng.normal(0, .023))
                temp = temp_base + .8 * np.sin(elapsed / 18) + rng.normal(0, .35)
                flow = max(10, flow_base + 1.1 * np.sin(elapsed / 20) + rng.normal(0, .6))
                detected = int(not short_active and rng.random() < (.018 + .035 * surface + .008 * max(0, local_z)))
                if detected:
                    short_active = True
                removed = int(short_active and not detected and rng.random() < .65)
                if removed:
                    short_active = False
                row = dict(cycle_id=cid, observed_hour=start + elapsed, available_at_hour=start + elapsed,
                           elapsed_hour=elapsed, dt_h=2., current_a=float(current),
                           cell_voltage_v=float(.27 + .0000011 * current + .0015 * (temp - 60) + .035 * short_active + rng.normal(0, .006)),
                           temperature_c=float(temp), flow_l_min=float(flow), on=on,
                           short_detected=detected, short_removed=removed,
                           glue_dose_g_h=float(glue_d * (1 + rng.normal(0, .025))),
                           thiourea_dose_g_h=float(thio_d * (1 + rng.normal(0, .025))),
                           hcl_dose_ml_h=float(hcl_d * (1 + rng.normal(0, .025))))
                obs.append(row)
                cu_in = cu_base + .7 * np.sin(elapsed / 29) + rng.normal(0, .15)
                as_in = as_base + .15 * np.sin(elapsed / 40) + rng.normal(0, .04)
                glue_m = max(.05, 1.3 * glue_d * np.exp(-.025 * (temp - 60)) + .15 * local_z + rng.normal(0, .15))
                thio_m = max(.02, 1.7 * thio_d * np.exp(-.035 * (temp - 60)) + rng.normal(0, .06))
                # Toy concentration balance: arbitrary net cathode/anode imbalance fraction .015.
                toy_drop = faraday(current * 120) * 1000 / (flow * 2) * .015
                chem = dict(cu_in_g_l=float(cu_in),
                            cu_out_g_l=float(cu_in - toy_drop + .12 * (ni - 9) + .1 * batch_z + rng.normal(0, .13)),
                            as_in_g_l=float(as_in),
                            as_out_g_l=float(as_in + .65 * anode_as + .05 * batch_z + .002 * elapsed + rng.normal(0, .05)),
                            ni_g_l=float(ni + rng.normal(0, .08)), bi_mg_l=float(bi + rng.normal(0, .02)),
                            h2so4_g_l=float(acid + rng.normal(0, .5)), cl_mg_l=float(cl + rng.normal(0, .6)),
                            glue_measured_mg_l=float(glue_m), thiourea_measured_mg_l=float(thio_m))
                chemistry.append(chem)
                if elapsed % 12 == 0:
                    delay = 6 if elapsed == 12 or (campaign + cell + int(elapsed / 12)) % 2 == 0 else 18
                    lab.append(dict(cycle_id=cid, observed_hour=start + elapsed,
                                    available_at_hour=start + elapsed + delay, elapsed_hour=elapsed, **chem))
            observations[cid], labs[cid] = obs, lab
            q = sum(x["current_a"] * x["dt_h"] * 3600 for x in obs)
            mean_t = np.mean([x["temperature_c"] for x in obs])
            j = np.mean([x["current_a"] for x in obs]) / area
            hot = np.mean([max(0, x["temperature_c"] - 63) for x in obs])
            short_n = sum(x["short_detected"] for x in obs)
            glue_mean = np.mean([x["glue_measured_mg_l"] for x in chemistry])
            efficiency_unbounded = (96.4 - .0011 * (j - 275) ** 2 - .52 * hot
                                    - .18 * short_n - .12 * (ni - 9) ** 2
                                    - .20 * (glue_mean - 4.5) ** 2 + .45 * batch_z + .5 * local_z + rng.normal(0, .65))
            efficiency = float(np.clip(efficiency_unbounded, 75, 99.5))
            s_unbounded = (85 - .3 * (mean_t - 62) ** 2 - 1.8 * short_n - .004 * (j - 275) ** 2
                           - 1.4 * (glue_mean - 4.5) ** 2 - 15 * surface - .25 * (cl - 45) ** 2 / 10
                           + 2 * batch_z + 2 * local_z + rng.normal(0, 3))
            s_grade = float(np.clip(s_unbounded, 0, 100))
            # Fixed deterministic publication delays keep sample counts equal across dataset seeds.
            label_delay = 24 + ((cell * 17 + campaign * 11) % 73)
            final_chem = chemistry[-6:]
            labels.append(dict(cycle_id=cid, label_available_at_hour=start + 168 + label_delay,
                               efficiency_pct=efficiency, s_grade_pct=s_grade,
                               cu_out_g_l=float(np.mean([x["cu_out_g_l"] for x in final_chem])),
                               as_out_g_l=float(np.mean([x["as_out_g_l"] for x in final_chem])),
                               final_actual_charge_c=q, final_mass_kg=faraday(q) * efficiency / 100))
            audit.append(dict(cycle_id=cid, batch_latent=float(batch_z), cell_latent=float(local_z),
                              drift=drift, efficiency_generator_clamped=efficiency != efficiency_unbounded,
                              grade_generator_clamped=s_grade != s_unbounded))
    return cycles, observations, labs, labels, audit


def reject_unknown(row, allowed, source):
    extra = set(row) - allowed
    if extra:
        raise ValueError(f"Forbidden/unknown {source} columns: {sorted(extra)}")


def features(meta, obs, labs, horizon):
    """Strict schema plus both observation-time and publication-time masks."""
    reject_unknown(meta, META, "metadata")
    for row in obs:
        reject_unknown(row, OBS_ALLOWED, "sensor")
    for row in labs:
        reject_unknown(row, LAB_ALLOWED, "laboratory")
    cutoff = meta["start_hour"] + horizon
    rows = [r for r in obs if r["observed_hour"] <= cutoff and r["available_at_hour"] <= cutoff]
    lr = [r for r in labs if r["observed_hour"] <= cutoff and r["available_at_hour"] <= cutoff]
    assert rows and lr
    raw = {k: meta[k] for k in ["active_area_m2", "planned_current_a", "anode_cu_pct", "anode_as_pct", "surface_index"]}
    raw["elapsed_hours"] = horizon
    for key in SENSORS:
        values = np.array([r[key] for r in rows])
        for suffix, value in [("mean", values.mean()), ("std", values.std()), ("last", values[-1])]:
            raw[f"{key}_{suffix}"] = float(value)
    for key in CHEM:
        vals = [r[key] for r in lr]
        raw[key + "_mean"] = float(np.mean(vals))
        raw[key + "_last"] = float(vals[-1])
    raw["lab_age_h"] = float(cutoff - lr[-1]["observed_hour"])
    raw["n_sensor_rows"] = len(rows)
    raw["n_available_labs"] = len(lr)
    q = sum(r["current_a"] * r["dt_h"] * 3600 for r in rows)
    phys = dict(prefix_charge_c=q, prefix_faraday_kg=faraday(q),
                prefix_mean_current_density_a_m2=raw["current_a_mean"] / meta["active_area_m2"],
                uptime_h=sum(r["on"] * r["dt_h"] for r in rows),
                hot_exposure_degree_h=sum(max(0, r["temperature_c"] - 63) * r["dt_h"] for r in rows),
                short_count=sum(r["short_detected"] for r in rows),
                removed_count=sum(r["short_removed"] for r in rows),
                glue_temp_interaction=raw["glue_measured_mg_l_mean"] * raw["temperature_c_mean"],
                cu_gradient_g_l=raw["cu_in_g_l_mean"] - raw["cu_out_g_l_mean"],
                as_gradient_g_l=raw["as_out_g_l_mean"] - raw["as_in_g_l_mean"],
                toy_cu_drop_g_l=faraday(raw["current_a_mean"] * 120) * 1000 / (raw["flow_l_min_mean"] * 2) * .015,
                glue_dose_g_per_kah=sum(r["glue_dose_g_h"] * r["dt_h"] for r in rows) / max(q / 3600000, 1e-9),
                remaining_planned_charge_c=meta["planned_current_a"] * (168 - horizon) * 3600)
    return raw, {**raw, **phys}, dict(n_sensor=len(rows), n_labs=len(lr), prefix_q=q,
                                    scenario_q=q + phys["remaining_planned_charge_c"])


def split_data(cfg, cycles, labels):
    lm = {x["cycle_id"]: x for x in labels}
    val_origin = cfg["validation_first_campaign"] * cfg["campaign_spacing_hours"] + min(cfg["horizons_hours"])
    test_origin = cfg["test_first_campaign"] * cfg["campaign_spacing_hours"] + min(cfg["horizons_hours"])
    rows = []
    for c in cycles:
        nominal = "train" if c["campaign_index"] < cfg["validation_first_campaign"] else (
            "validation" if c["campaign_index"] < cfg["test_first_campaign"] else "test")
        fit_origin = val_origin if nominal == "train" else test_origin if nominal == "validation" else None
        ready = lm[c["cycle_id"]]["label_available_at_hour"]
        purge = fit_origin is not None and ready > fit_origin
        rows.append(dict(cycle_id=c["cycle_id"], batch_id=c["batch_id"], start_hour=c["start_hour"],
                         nominal_split=nominal, split="purged_" + nominal if purge else nominal,
                         label_available_at_hour=ready, required_label_ready_origin_hour=fit_origin))
    return rows, dict(validation_model_fit_origin_hour=val_origin, test_selection_origin_hour=test_origin,
                      final_fit_uses_train_only=True, validation_used_for_hyperparameter_choice=True,
                      test_used_for_selection=False)


def fit_predict(model_id, xtrain, ytrain, xval, yval, xtest, seed, cfg):
    if model_id == "mean_baseline":
        pred = np.tile(ytrain.mean(axis=0), (len(xtest), 1))
        pv = np.tile(ytrain.mean(axis=0), (len(xval), 1))
        return pred, pv, {"kind": "mean", "mean": ytrain.mean(axis=0)}, {"selected": "train_mean"}, []
    candidates, convergences = [], []
    choices = cfg["mlp_alpha_candidates"] if model_id == "shared_mlp_physics" else cfg["catboost_iterations_candidates"]
    for choice in choices:
        training_diagnostics = None
        if model_id == "shared_mlp_physics":
            xs, ys = StandardScaler().fit(xtrain), StandardScaler().fit(ytrain)
            estimator = MLPRegressor(hidden_layer_sizes=tuple(cfg["mlp_hidden_layer_sizes"]), alpha=choice,
                                     max_iter=cfg["mlp_max_iter"], random_state=seed, learning_rate_init=.004,
                                     early_stopping=False, n_iter_no_change=60, tol=1e-5)
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always", ConvergenceWarning)
                estimator.fit(xs.transform(xtrain), ys.transform(ytrain))
            convergences.extend([str(w.message) for w in caught])
            model = dict(kind="mlp", estimator=estimator, x_scaler=xs, y_scaler=ys)
            convergence_warnings = [str(w.message) for w in caught if issubclass(w.category, ConvergenceWarning)]
            unresolved = bool(convergence_warnings) or estimator.n_iter_ >= cfg["mlp_max_iter"]
            training_diagnostics = dict(alpha=choice, n_iter=int(estimator.n_iter_), max_iter=cfg["mlp_max_iter"],
                                        training_loss=float(estimator.loss_), best_training_loss=float(min(estimator.loss_curve_)),
                                        training_loss_tail_61=[float(v) for v in estimator.loss_curve_[-61:]],
                                        convergence_warning_count=len(convergence_warnings), convergence_warnings=convergence_warnings,
                                        iteration_limit_hit=bool(estimator.n_iter_ >= cfg["mlp_max_iter"]),
                                        status="iteration_limit_unresolved" if unresolved else "training_tolerance_stop",
                                        status_note="sklearn training-loss stopping condition only; not proof of a global optimum")
        else:
            heads = []
            for t in range(4):
                head = CatBoostRegressor(iterations=choice, depth=cfg["catboost_depth"], learning_rate=.055,
                                         loss_function="RMSE", random_seed=seed, thread_count=2,
                                         verbose=False, allow_writing_files=False)
                head.fit(xtrain, ytrain[:, t])
                heads.append(head)
            model = dict(kind="catboost", heads=heads)
        pv = predict(model, xval)
        # User priority: efficiency first, S-grade only breaks an exact tie.
        # Auxiliary Cu/As errors never decide the selected hyperparameter.
        score = (float(np.mean(np.abs(pv[:, 0] - yval[:, 0]))),
                 float(np.mean(np.abs(pv[:, 1] - yval[:, 1]))))
        candidates.append((score, choice, model, pv, training_diagnostics))
    best = min(candidates, key=lambda item: item[0])
    selected = {"selected": best[1], "criterion": "lexicographic validation efficiency MAE first, S MAE exact-tie break; auxiliaries excluded",
                "candidate_scores": [{"value": x[1], "efficiency_mae_pp": x[0][0], "s_grade_mae_pp": x[0][1]} for x in candidates]}
    if model_id == "shared_mlp_physics":
        for record, candidate in zip(selected["candidate_scores"], candidates):
            record["training_diagnostics"] = candidate[4]
        selected["training_diagnostics"] = best[4]
    return predict(best[2], xtest), best[3], best[2], selected, convergences


def predict(model, x):
    if model["kind"] == "mean":
        return np.tile(model["mean"], (len(x), 1))
    if model["kind"] == "mlp":
        return model["y_scaler"].inverse_transform(model["estimator"].predict(model["x_scaler"].transform(x)))
    return np.column_stack([h.predict(x) for h in model["heads"]])


def metrics(y, p):
    assert np.isfinite(p).all()
    return {"mae": float(np.mean(np.abs(y - p))), "rmse": float(np.sqrt(np.mean((y - p) ** 2)))}


def self_checks(cfg, cycles, obs, labs, labels, splits):
    c = cycles[0]
    o, l = obs[c["cycle_id"]], labs[c["cycle_id"]]
    raw, orig, audit = features(c, o, l, 24)
    mo, ml = copy.deepcopy(o), copy.deepcopy(l)
    for row in mo:
        if row["observed_hour"] > c["start_hour"] + 24:
            for k in SENSORS:
                row[k] = -99999.
    for row in ml:
        if row["observed_hour"] > c["start_hour"] + 24:
            for k in CHEM:
                row[k] = -99999.
    assert orig == features(c, mo, ml, 24)[1]
    delayed = [r for r in l if r["observed_hour"] <= 24 and r["available_at_hour"] > 24]
    assert delayed
    ml = copy.deepcopy(l)
    for row in ml:
        if row["available_at_hour"] > 24:
            for k in CHEM:
                row[k] = 99999.
    assert orig == features(c, o, ml, 24)[1]
    rejected = []
    for column in ["final_mass_kg", "efficiency_pct", "s_grade_pct", "final_vision", "future_actual_current_a", "final_actual_charge_c"]:
        injected = copy.deepcopy(o)
        injected[0][column] = 1
        try:
            features(c, injected, l, 24)
        except ValueError:
            rejected.append(column)
    assert len(rejected) == 6
    groups = {s: {r["batch_id"] for r in splits if r["split"] == s} for s in ["train", "validation", "test"]}
    assert not (groups["train"] & groups["validation"] or groups["train"] & groups["test"] or groups["validation"] & groups["test"])
    for r in splits:
        if r["split"] in ["train", "validation"]:
            assert r["label_available_at_hour"] <= r["required_label_ready_origin_hour"]
    for section in {c["section_id"] for c in cycles}:
        cs = sorted([c for c in cycles if c["section_id"] == section], key=lambda x: x["start_hour"])
        assert all(a["end_hour"] <= b["start_hour"] for a, b in zip(cs, cs[1:]))
    assert math.isclose(faraday(33000 * 168 * 3600), 7 * faraday(33000 * 24 * 3600), rel_tol=1e-14)
    assert sum(map(len, obs.values())) == 480 * 84
    assert sum(map(len, labs.values())) == 480 * 14
    assert len(labels) == len(cycles) == 480
    assert all(math.isclose(x["final_mass_kg"], faraday(x["final_actual_charge_c"]) * x["efficiency_pct"] / 100) for x in labels)
    return dict(future_row_value_invariance=True, delayed_lab_value_invariance=True,
                delayed_labs_blocked_example=len(delayed), forbidden_injections_rejected=rejected,
                batches_and_cycles_disjoint=True, label_ready_assertions=True, same_section_no_overlap=True,
                faraday_168h_equals_7_times_24h=True, final_mass_identity=True,
                final_mass_identity_is_independent_validation=False,
                source_rows=dict(cycles=len(cycles), sensor_rows=sum(map(len, obs.values())),
                                 laboratory_rows=sum(map(len, labs.values())), labels=len(labels)))


def summarize(rows, key):
    maes = [r[key]["mae"] for r in rows]
    rmses = [r[key]["rmse"] for r in rows]
    return dict(mae_mean=float(np.mean(maes)), mae_min=float(min(maes)), mae_max=float(max(maes)),
                rmse_mean=float(np.mean(rmses)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=ROOT / "config.json")
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text())
    start_clock = time.time()
    all_rows, all_checks, negative, warning_log = [], [], [], []
    for seed in cfg["seeds"]:
        print(f"seed={seed}: generating synthetic data", flush=True)
        out = ROOT / "data" / f"seed_{seed}"
        cycles, obs, labs, labels, latent = generate(cfg, seed)
        splits, origins = split_data(cfg, cycles, labels)
        checks = self_checks(cfg, cycles, obs, labs, labels, splits)
        checks.update(seed=seed, fit_origins=origins)
        all_checks.append(checks)
        write_csv(out / "cycles.csv", cycles)
        write_csv(out / "observations.csv", [r for c in cycles for r in obs[c["cycle_id"]]])
        write_csv(out / "laboratory.csv", [r for c in cycles for r in labs[c["cycle_id"]]])
        write_csv(out / "labels.csv", labels)
        write_csv(out / "generator_latent_AUDIT_ONLY.csv", latent)
        write_csv(out / "split_manifest.csv", splits)
        dump(out / "fit_origins.json", origins)
        labmap = {l["cycle_id"]: l for l in labels}
        splitmap = {r["cycle_id"]: r["split"] for r in splits}
        y = np.array([[labmap[c["cycle_id"]][k] for k in TARGETS] for c in cycles])
        idx = {s: np.array([i for i, c in enumerate(cycles) if splitmap[c["cycle_id"]] == s]) for s in ["train", "validation", "test"]}
        assert len(set(idx["train"]) & set(idx["test"])) == 0
        for horizon in cfg["horizons_hours"]:
            feat = [features(c, obs[c["cycle_id"]], labs[c["cycle_id"]], horizon) for c in cycles]
            names_raw, names_phys = list(feat[0][0]), list(feat[0][1])
            xraw = np.array([[f[0][k] for k in names_raw] for f in feat])
            xphys = np.array([[f[1][k] for k in names_phys] for f in feat])
            assert np.isfinite(xraw).all() and np.isfinite(xphys).all()
            write_csv(out / f"features_{horizon:03d}h.csv", [dict(cycle_id=c["cycle_id"], **f[1]) for c, f in zip(cycles, feat)])
            for model_id in [m["id"] for m in MODELS]:
                x = xraw if model_id == "catboost_raw" else xphys
                xt, xv, xe = [x[idx[s]] for s in ["train", "validation", "test"]]
                yt, yv, ye = [y[idx[s]] for s in ["train", "validation", "test"]]
                pred, pv, model, selected, warns = fit_predict(model_id, xt, yt, xv, yv, xe, seed, cfg)
                warning_log.extend([dict(seed=seed, horizon=horizon, model_id=model_id, warning=w) for w in warns])
                mass_true = np.array([labmap[cycles[i]["cycle_id"]]["final_mass_kg"] for i in idx["test"]])
                scenario_q = np.array([feat[i][2]["scenario_q"] for i in idx["test"]])
                mass_pred = pred[:, 0] / 100 * faraday(scenario_q)
                assert np.isfinite(mass_pred).all()
                row = dict(seed=seed, horizon_hours=horizon, model_id=model_id,
                           n_train=len(yt), n_validation=len(yv), n_test=len(ye), selected=selected,
                           targets={k: metrics(ye[:, j], pred[:, j]) for j, k in enumerate(TARGETS)},
                           conditional_mass_kg=metrics(mass_true, mass_pred),
                           validation_targets={k: metrics(yv[:, j], pv[:, j]) for j, k in enumerate(TARGETS)},
                           out_of_bounds_rate={k: float(np.mean((pred[:, j] < 0) | ((pred[:, j] > 100) if j < 2 else False))) for j, k in enumerate(TARGETS)},
                           conditional_mass_negative_rate=float(np.mean(mass_pred < 0)),
                           scenario_charge_mae_pct=float(np.mean([abs(scenario_q[n] - labmap[cycles[i]["cycle_id"]]["final_actual_charge_c"]) / labmap[cycles[i]["cycle_id"]]["final_actual_charge_c"] * 100 for n, i in enumerate(idx["test"])])),
                           source_rows={"sensor_min": min(f[2]["n_sensor"] for f in feat), "sensor_max": max(f[2]["n_sensor"] for f in feat),
                                        "lab_min": min(f[2]["n_labs"] for f in feat), "lab_max": max(f[2]["n_labs"] for f in feat)})
                all_rows.append(row)
                artifact = dict(model=model, feature_names=names_raw if model_id == "catboost_raw" else names_phys,
                                synthetic=True, seed=seed, horizon_hours=horizon, fit_origins=origins)
                mp = ROOT / "models" / f"seed_{seed}" / f"{horizon:03d}h_{model_id}.pkl"
                mp.parent.mkdir(parents=True, exist_ok=True)
                with mp.open("wb") as f:
                    pickle.dump(artifact, f)
                pp = [dict(cycle_id=cycles[i]["cycle_id"], **{f"true_{k}": ye[n, j] for j, k in enumerate(TARGETS)},
                           **{f"pred_{k}": pred[n, j] for j, k in enumerate(TARGETS)},
                           true_final_mass_kg=mass_true[n], predicted_conditional_mass_kg=mass_pred[n]) for n, i in enumerate(idx["test"])]
                write_csv(ROOT / "predictions" / f"seed_{seed}" / f"{horizon:03d}h_{model_id}.csv", pp)
                if horizon == cfg["negative_control_horizon_hours"] and model_id == "catboost_physics":
                    for shuffle_seed in cfg["shuffle_seeds"]:
                        perm = np.random.default_rng(shuffle_seed).permutation(len(yt))
                        heads = []
                        for j in range(4):
                            m = CatBoostRegressor(iterations=selected["selected"], depth=cfg["catboost_depth"], learning_rate=.055,
                                                  loss_function="RMSE", random_seed=seed, thread_count=2,
                                                  verbose=False, allow_writing_files=False)
                            m.fit(xt, yt[perm, j])
                            heads.append(m)
                        ps = predict(dict(kind="catboost", heads=heads), xe)
                        negative.append(dict(seed=seed, shuffle_seed=shuffle_seed, horizon_hours=horizon,
                                             model_id=model_id, train_labels_jointly_shuffled=True,
                                             selected_iterations_frozen_before_shuffle=selected["selected"],
                                             targets={k: metrics(ye[:, j], ps[:, j]) for j, k in enumerate(TARGETS)},
                                             unshuffled_targets=row["targets"]))
            print(f"seed={seed} horizon={horizon}: four models complete", flush=True)
        dump(ROOT / f"metrics_seed_{seed}.json", dict(schema_version="1.0", synthetic=True, seed=seed,
                                                      results=[r for r in all_rows if r["seed"] == seed]))
    agg = []
    for horizon in cfg["horizons_hours"]:
        for m in MODELS:
            rr = [r for r in all_rows if r["horizon_hours"] == horizon and r["model_id"] == m["id"]]
            tt = {k: summarize([r["targets"] for r in rr], k) for k in TARGETS}
            counts = {k: rr[0][k] for k in ["n_train", "n_validation", "n_test"]}
            assert all(all(r[k] == counts[k] for k in counts) for r in rr)
            agg.append(dict(horizon_hours=horizon, model_id=m["id"], targets=tt,
                            conditional_mass_kg=summarize(rr, "conditional_mass_kg"), **counts,
                            out_of_bounds_rate={k: float(np.mean([r["out_of_bounds_rate"][k] for r in rr])) for k in TARGETS}))
    payload = dict(schema_version="1.0", synthetic=True, horizons_hours=cfg["horizons_hours"], seeds=cfg["seeds"], models=MODELS,
                   targets={k: dict(name=n, unit=u, priority=i + 1) for i, (k, n, u) in enumerate(zip(TARGETS,
                             ["전류효율", "Vision S등급률", "주기 말 출구 Cu", "주기 말 출구 As"],
                             ["percentage points", "percentage points", "g/L", "g/L"]))},
                   results=agg, uncertainty_note="min/max are three independent synthetic dataset seed means, not confidence intervals",
                   limitations=["synthetic DGP only; no field validity or causal effect demonstrated", "168h is end-cycle explanation, not early warning", "conditional mass depends on remaining planned current scenario"],
                   generated_at_utc=datetime.now(timezone.utc).isoformat())
    dump(ROOT / "metrics.json", payload)
    dump(ROOT / "validation_checks.json", dict(synthetic=True, all_assertions_passed=True, per_seed=all_checks,
                                               finite_features_and_predictions=True, predictions_clipped=False,
                                               warning_count=len(warning_log), warnings=warning_log,
                                               out_of_bounds=[dict(seed=r["seed"], horizon_hours=r["horizon_hours"], model_id=r["model_id"],
                                                                   rates=r["out_of_bounds_rate"], negative_mass_rate=r["conditional_mass_negative_rate"]) for r in all_rows]))
    dump(ROOT / "negative_controls.json", dict(synthetic=True, design="72h physics CatBoost; joint training-label permutation; no numeric pass gate; three fixed shuffles per seed",
                                               results=negative))
    convergence_rows = []
    for r in all_rows:
        if r["model_id"] == "shared_mlp_physics":
            for candidate in r["selected"]["candidate_scores"]:
                convergence_rows.append(dict(seed=r["seed"], horizon_hours=r["horizon_hours"],
                                             selected=candidate["value"] == r["selected"]["selected"],
                                             **candidate["training_diagnostics"]))
    candidate_unresolved = sum(r["status"] == "iteration_limit_unresolved" for r in convergence_rows)
    selected_unresolved = sum(r["selected"] and r["status"] == "iteration_limit_unresolved" for r in convergence_rows)
    dump(ROOT / "convergence_diagnostics.json", dict(synthetic=True, original_max_iter=450, max_iter=cfg["mlp_max_iter"],
                                                     bounded_extension_count=1, candidate_fits=len(convergence_rows),
                                                     selected_models=sum(r["selected"] for r in convergence_rows),
                                                     all_candidate_warning_count=sum(r["convergence_warning_count"] for r in convergence_rows),
                                                     selected_candidate_warning_count=sum(r["convergence_warning_count"] for r in convergence_rows if r["selected"]),
                                                     rejected_candidate_warning_count=sum(r["convergence_warning_count"] for r in convergence_rows if not r["selected"]),
                                                     unresolved_candidates=candidate_unresolved, unresolved_selected_models=selected_unresolved,
                                                     test_scores_used_to_extend_budget=False,
                                                     no_further_optimizer_adjustments=True, candidates=convergence_rows))
    manifest = []
    for p in sorted(ROOT.rglob("*")):
        if p.is_file() and ".venv" not in p.parts and "__pycache__" not in p.parts and p.name != "run_manifest.json":
            manifest.append(dict(path=str(p.relative_to(ROOT)), size=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    dump(ROOT / "run_manifest.json", dict(synthetic=True, elapsed_seconds=time.time() - start_clock,
                                         python=platform.python_version(), numpy=np.__version__, sklearn=sklearn.__version__, catboost=catboost.__version__,
                                         config_sha256=hashlib.sha256(args.config.read_bytes()).hexdigest(), files=manifest))
    lines = ["# 합성 모델 실행 결과", "", "**모든 데이터와 결과는 합성 예시다. 현장 예측·조기경보·인과효과·최적 조업 조건을 입증하지 않는다.**", "",
             "전류효율이 1순위, Vision S등급률이 2순위다. 3개 독립 합성 데이터 seed의 시험 MAE 평균을 아래에 모두 표시했다.",
             "min/max는 seed 간 범위이며 신뢰구간이 아니다. 168h는 주기 말 설명이다. 모델 선택은 검증 기간으로 끝내고 시험 결과로 재선택하지 않았다.", "",
             "|시점 h|모델|효율 MAE pp|S MAE pp|Cu MAE g/L|As MAE g/L|조건부 질량 MAE kg|", "|---:|---|---:|---:|---:|---:|---:|"]
    for r in agg:
        vals = [f"{r['targets'][k]['mae_mean']:.3f}" for k in TARGETS]
        lines.append(f"|{r['horizon_hours']}|{r['model_id']}|" + "|".join(vals) + f"|{r['conditional_mass_kg']['mae_mean']:.2f}|")
    lines.extend(["", "## 고정 분할과 학습", "", f"각 seed: 학습 {agg[0]['n_train']}, 검증 {agg[0]['n_validation']}, 시험 {agg[0]['n_test']} 주기. 원래 480주기에서 정답 공개 지연에 따른 purge를 적용했다.",
                  "원래 train/validation/test 캠페인은 0–8 / 9–11 / 12–15다. 모든 시점·모델에서 같은 그룹 분할을 쓴다.",
                  "StandardScaler는 MLP의 학습 입력과 학습 정답으로만 fit했다. MLP 내부 무작위 조기종료는 껐고, 2개 고정 후보를 외부 검증 기간에서만 비교했다. 후보 선택은 검증 효율 MAE 우선, 정확히 같은 경우 S MAE 순이며 Cu/As는 선택 기준에 넣지 않았다.",
                  "", "## 해석 범위", "", "CatBoost는 실제 학습된 독립 4개 회귀기다. 물리 특징 추가 전후는 같은 split·동일 후보 설정으로 비교했다. 공유 MLP는 4출력을 함께 학습한 단순 모델이며 Liu의 GCN–Transformer/CBAM 재현이 아니다.",
                  "Cheng은 공개 요약에서 얻은 트리·수지 아이디어의 참고이며 정확한 결합 구현·AdaBoost·SHAP/PDP/ICE는 이번에 구현하지 않았다. Correa의 LSTM+Attention 시계열 비교는 후속 과제로 남겼다.",
                  "", "## 음성 대조 및 소프트웨어 검증", "", "72h에서 각 seed마다 3번의 고정 학습 정답 셔플을 실행했다. negative_controls.json에 전체 결과를 보존했으며 일률적인 수치 통과 기준은 두지 않았다.",
                  f"self-check assertion은 모두 통과했다. 수렴 경고 {len(warning_log)}건을 숨기지 않고 validation_checks.json에 보존했다. 예측값은 clipping하지 않았으며 범위 이탈률도 같은 파일에 기록했다.",
                  f"공유 MLP는 원래 450회 후보42건의 반복 한도 경고 때문에 같은 구조·학습률·후보·분할을 유지하고 최대 반복수만 {cfg['mlp_max_iter']}회로 한 번 늘렸다. 원래 결과는 archive/capped450/에 보존했다. 설정 변경은 훈련 수렴 상태에 근거했으며 시험 점수를 사용하지 않았다.",
                  f"전체 후보 {len(convergence_rows)}건 중 반복 한도 미해결 {candidate_unresolved}건, 선택된21모델 중 미해결 {selected_unresolved}건이다. convergence_diagnostics.json에 탈락 후보까지 n_iter·훈련 손실·경고를 기록했다. 경고가 없더라도 훈련 손실 정지 기준을 만족했다는 뜻이며 전역 최적점·현장 성능을 입증하지 않는다.",
                  "미래 행 변조 불변성·지연 분석 차단·금지 열 거부·그룹/가용 시각 분할·Faraday 7배·행 수·유한값 검사는 구현과 가정 DGP의 검사다. 현장 일반화 검증이 아니다.",
                  "", "## 조건부 최종 질량", "", "예측 효율 × Faraday(관측 prefix 전하 + 남은 시간 × 시작 전에 정한 계획 전류). 실제 미래 전류를 입력하지 않았다. 미래 정전·전류 변경이 있으면 시나리오가 빗나간다.",
                  "168h에는 남은 계획 전하가 0이다. 정답 질량도 실제 최종 전하 × 합성 효율로 만들었으므로 두 값의 항등식은 구성상의 결과이며 독립 물리 검증이 아니다.", ""])
    (ROOT / "results_summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"DONE elapsed={time.time() - start_clock:.1f}s", flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
