#!/usr/bin/env python3
"""Portable synthetic-run CSV/feature verifier; no archived run or pickle needed."""
import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


def read(path):
    with path.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))


def close(a,b,tol=1e-8):
    assert math.isclose(float(a),float(b),rel_tol=1e-10,abs_tol=tol),(a,b)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    ap.add_argument('--output',type=Path)
    args=ap.parse_args();root=args.root.resolve()
    cfg=json.loads((root/'config.json').read_text());agg=json.loads((root/'metrics.json').read_text())
    assert agg['synthetic'] is True
    targets=list(agg['targets'])
    # Target metadata uses a mapping keyed by the canonical output names.
    expected=['efficiency_pct','s_grade_pct','cu_out_g_l','as_out_g_l']
    assert set(targets)==set(expected)
    nmetric=nfeature=nmass=0;all_stats=defaultdict(list);groups=[]
    for seed in cfg['seeds']:
        d=root/'data'/f'seed_{seed}'
        cycles=read(d/'cycles.csv');obs=defaultdict(list);labs=defaultdict(list)
        for r in read(d/'observations.csv'):obs[r['cycle_id']].append(r)
        for r in read(d/'laboratory.csv'):labs[r['cycle_id']].append(r)
        labels={r['cycle_id']:r for r in read(d/'labels.csv')};splits=read(d/'split_manifest.csv')
        assert len(cycles)==len(labels)==480 and sum(map(len,obs.values()))==40320 and sum(map(len,labs.values()))==6720
        counts=Counter(r['split'] for r in splits)
        batch={s:{r['batch_id'] for r in splits if r['split']==s} for s in ['train','validation','test']}
        assert not (batch['train']&batch['validation'] or batch['train']&batch['test'] or batch['test']&batch['validation'])
        for r in splits:
            if r['split'] in ['train','validation']:assert float(r['label_available_at_hour'])<=float(r['required_label_ready_origin_hour'])
        sr=json.loads((root/f'metrics_seed_{seed}.json').read_text())['results']
        for h in cfg['horizons_hours']:
            fs={r['cycle_id']:r for r in read(d/f'features_{h:03d}h.csv')}
            assert not (set(next(iter(fs.values())))&{'efficiency_pct','s_grade_pct','final_mass_kg','final_actual_charge_c','future_actual_current_a'})
            for c in cycles:
                cid=c['cycle_id'];cut=float(c['start_hour'])+h
                oo=[r for r in obs[cid] if float(r['observed_hour'])<=cut and float(r['available_at_hour'])<=cut]
                ll=[r for r in labs[cid] if float(r['observed_hour'])<=cut and float(r['available_at_hour'])<=cut]
                assert len(oo)==int(fs[cid]['n_sensor_rows']) and len(ll)==int(fs[cid]['n_available_labs'])
                q=sum(float(r['current_a'])*float(r['dt_h'])*3600 for r in oo)
                close(q,fs[cid]['prefix_charge_c'])
                close(q*.063546/(2*96485.33212),fs[cid]['prefix_faraday_kg'])
                close(float(c['planned_current_a'])*(168-h)*3600,fs[cid]['remaining_planned_charge_c'])
                close(sum(float(r['cu_in_g_l']) for r in ll)/len(ll),fs[cid]['cu_in_g_l_mean'])
                if h==168:close(q,labels[cid]['final_actual_charge_c'])
                nfeature+=1
            for model in [m['id'] for m in agg['models']]:
                rows=read(root/'predictions'/f'seed_{seed}'/f'{h:03d}h_{model}.csv')
                r=next(r for r in sr if r['horizon_hours']==h and r['model_id']==model)
                assert len(rows)==r['n_test']==counts['test']
                for name in expected+['conditional_mass_kg']:
                    if name=='conditional_mass_kg':err=[float(x['predicted_conditional_mass_kg'])-float(x['true_final_mass_kg']) for x in rows];source=r['conditional_mass_kg']
                    else:err=[float(x['pred_'+name])-float(x['true_'+name]) for x in rows];source=r['targets'][name]
                    assert all(math.isfinite(v) for v in err)
                    mae=sum(abs(e) for e in err)/len(err);rmse=math.sqrt(sum(e*e for e in err)/len(err))
                    close(mae,source['mae']);close(rmse,source['rmse']);nmetric+=2;all_stats[(h,model,name)].append((mae,rmse))
                for x in rows:
                    f=fs[x['cycle_id']];q=float(f['prefix_charge_c'])+float(f['remaining_planned_charge_c'])
                    close(float(x['pred_efficiency_pct'])/100*.063546*q/(2*96485.33212),x['predicted_conditional_mass_kg']);nmass+=1
        groups.append({'seed':seed,'cycles':dict(counts),'campaigns':{s:len(v) for s,v in batch.items()}})
    for row in agg['results']:
        for t in expected+['conditional_mass_kg']:
            source=row['conditional_mass_kg'] if t=='conditional_mass_kg' else row['targets'][t]
            vals=all_stats[(row['horizon_hours'],row['model_id'],t)]
            ma=[v[0] for v in vals];rm=[v[1] for v in vals]
            close(source['mae_mean'],sum(ma)/len(ma));close(source['mae_min'],min(ma));close(source['mae_max'],max(ma));close(source['rmse_mean'],sum(rm)/len(rm))
    result={'synthetic':True,'all_assertions_passed':True,'metrics_recomputed':nmetric,'cycle_horizon_feature_checks':nfeature,'conditional_mass_row_checks':nmass,'splits':groups,'scope':'CSV arithmetic, aggregate binding, availability-based stored features, groups/label-ready times, and SI mass projection. No model reloading, archival comparison or field validation.'}
    dest=args.output or root/'reproduction_verification.json';dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
