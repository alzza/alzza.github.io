# 전해정련 합성 모델 · 공개 재실행 패키지

모든 데이터는 생성식으로 만든 가상 기록입니다. 실제 회사 MES·Vision·분석 원본은 포함하지 않았습니다. 계수와 농도·운전 범위는 현장 설정값이 아닙니다.

## 실행

검증한 환경은 Python 3.9.20, numpy 1.26.4, scikit-learn 1.5.2, catboost 1.2.8입니다. 전체 전이 의존성은 requirements.lock.txt에 고정했습니다. 아래 명령은 압축을 푼 상위 폴더에서 시작합니다.

```bash
cd electrorefining-synthetic-model
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock.txt
.venv/bin/python pipeline.py
.venv/bin/python verify_reproduction.py
```

pipeline.py가 원천 CSV·특징·84개 학습 모델·예측·지표를 새로 만듭니다. 기본 설정은 고정된 3개 생성 시드, 7개 예측 시점, 4종 모델입니다. 원래 Mac 실행은 약4분이었으며 환경에 따라 다릅니다. 플랫폼에 따라 작은 부동소수점 차이가 날 수 있습니다. 결과·가상환경·모델 피클은 생성되며 ZIP에 미리 포함하지 않았습니다.

## 무엇을 비교하나요?

- 학습 평균, 관측 요약 CatBoost, 물리량 추가 CatBoost, 물리량을 입력한 공유4출력 MLP.
- 1순위 효율·2순위 S등급률은 %p 오차, 보조 출구 Cu·As는 g/L, 조건부 최종 질량은 kg로 평가.
- 480개 가상 대표Cell 작업은 16캠페인에 묶입니다. 학습246/검증65/시험120작업은9/3/4캠페인입니다. 시험120작업은 독립 실험120회가 아닙니다.
- 24~144시간은 공개된 앞부분만 사용하며168시간은 종료 설명입니다. 실제 미래 전류 대신 당시의 계획 전류만 질량 시나리오에 사용합니다.

## 검증 범위

휴대용 verify_reproduction.py는 CSV 오차840개, 집계값, 10,080개 작업·시점의 저장 특징과 공개 지연, 묶음·정답 공개 시각, 전하·질량 산술을 표준 라이브러리로 대조합니다. 이전450회 실행 아카이브나 모델 피클을 요구하지 않습니다. 모델을 다시 로드하거나 이전 실행의 바이트 불변성을 검사하는 스크립트는 아닙니다.

동봉한 artifact_verification.json·validation_checks.json은 원래 로컬 실행의 검토 기록입니다. 그 로컬 실행에서는 저장 모델24개 재로딩과 원본 보존·기준 모델 불변성도 별도로 확인했습니다. 완전한 로컬 폴더에는 그 원본 아카이브와 verify_outputs.py가 남아 있습니다. 휴대용 검증과 원래 검토 기록을 같은 검사 범위라고 해석하지 않습니다.

max_iter는 최초450회 후보들의 수렴 경고를 근거로, 시험 점수와 무관하게3000회로 한 번 확장했습니다. 최종42후보·선택21MLP는 훈련 손실 변화 정지 기준을 만족했고 경고0건이었습니다. 수렴 진단·예산 결정도 동봉했습니다. 학습 정지는 전역 최적성·현장 일반화의 증명이 아닙니다.

## 논문과 현장에 적용할 때

Cheng의 트리·수지 관점과 Liu의 물리량·다중 결과 발상만 단순화했습니다. Cheng 전문·TableS1은 미확보이고 AdaBoost·SHAP/PDP/ICE는 구현하지 않았습니다. Liu의 GCN–Transformer·CBAM·물리 손실·직접 Butler–Volmer 식별과 Correa의 LSTM·Attention도 이번 구현이 아닙니다.

합성 S비율은 실제 검사 판수 분모를 재현하지 않았습니다. 농도식은 임의 장난감 수지이며, 질량을 같은 Faraday 식으로 생성하고 확인한 일치는 독립 물리 검증이 아닙니다. 현재 생성기는168시간 고정 주기입니다. cycle_hours 설정만 바꿔 다른 작업 길이를 재현하지 마세요. 센서 지연은0, 분석 지연은6/18시간, 정답 지연은24–96시간인 합성 사례입니다.

같은 생성식에서의 오차가 실제 공정 정확도·조기경보·원인·조치 효과를 입증하지 않습니다. 공유 MLP와 CatBoost는 구조도 달라 차이를 공유 학습의 효과만으로 해석할 수 없습니다.

- Cheng: https://doi.org/10.1016/j.jclepro.2026.147643
- Liu: https://doi.org/10.1016/j.matdes.2026.116175
- 설명·전체 결과: https://alzza.github.io/notes/electrorefining-attention.html
